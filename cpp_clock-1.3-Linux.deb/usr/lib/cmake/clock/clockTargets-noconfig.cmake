#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "clock::clock" for configuration ""
set_property(TARGET clock::clock APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(clock::clock PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NOCONFIG "CXX"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libclock.a"
  )

list(APPEND _cmake_import_check_targets clock::clock )
list(APPEND _cmake_import_check_files_for_clock::clock "${_IMPORT_PREFIX}/lib/libclock.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
